from brain_games import even_game


def main():
    even_game.the_even()


if __name__ == '__main__':
    main()
