from brain_games.games.even_game import run_even_game


def main():
    run_even_game()


if __name__ == '__main__':
    main()
