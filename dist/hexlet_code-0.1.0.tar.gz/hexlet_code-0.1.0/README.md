### Hexlet tests and linter status:
[![Actions Status](https://github.com/RetY2244/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/RetY2244/python-project-49/actions)
<a href="https://codeclimate.com/github/RetY2244/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/60bb25d88783fc5688a8/maintainability" /></a>
https://asciinema.org/a/633217
https://asciinema.org/a/633256