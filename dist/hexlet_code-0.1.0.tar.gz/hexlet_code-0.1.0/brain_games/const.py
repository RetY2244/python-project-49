EVEN_INSTRUCTION = '''Answer "yes" if the number is even, otherwise answer "no".'''
CALC_INSTRUCTION = 'What is the result of the expression?'
GSD_INSTRUCTION = 'Find the greatest common divisor of given numbers.'
PROGRESS_INSTRUCTION = 'What number is missing in the progression?'
PRIME_INSTRUCTION = 'Answer "yes" if given number is prime. Otherwise answer "no".'
MATH_SIGNS = ('+', '-', '*')
MAX_PROGRESSION = 10
MIN_PROGRESSION = 5

AMOUNT_OF_ROUNDS = 3
