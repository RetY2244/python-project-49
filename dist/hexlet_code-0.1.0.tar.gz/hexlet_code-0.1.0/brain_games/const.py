EVEN_INSTRUCTION = '''Answer "yes" if the number is even, otherwise answer "no".'''
CALC_INSTRUCTION = 'What is the result of the expression?'
GSD_INSTRUCTION = 'Find the greatest common divisor of given numbers.'
MATH_SIGNS = ('+', '-', '*')


AMOUNT_OF_ROUNDS = 3
