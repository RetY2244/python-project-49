from brain_games.games.calc_game import run_calc_game


def main():
    run_calc_game()


if __name__ == '__main__':
    main()
